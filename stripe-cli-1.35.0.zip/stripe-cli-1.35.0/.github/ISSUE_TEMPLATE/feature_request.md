---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

### Problem
_What are you trying to do?_

### Feature
_What would help you accomplish your original task_

### Examples
_Any example interaction you expect_
