// This file is generated; DO NOT EDIT.

package requests

// StripeVersionHeaderValue is the api version header value
const StripeVersionHeaderValue = "2026-01-28.clover"

// StripePreviewVersionHeaderValue is the api version header value for preview features
const StripePreviewVersionHeaderValue = "2026-01-28.preview"
